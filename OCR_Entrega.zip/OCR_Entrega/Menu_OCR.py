# -*- coding: utf-8 -*-
"""
Created on Sat Feb 27 00:36:09 2016

@author: Cocoletzi
"""
import KNN_funciones #importamos KNN_funciones para el manejo de las función KNN que programamos con anterioridad
import Dataset #importamos Dataset para la creacion del nuestro Dataset
import os #importamos os para usar comandos propios del Sistema Operativo
print ("Qué deseas realizar:")#impresion del menú para realizar la primera acción
opcion=int(input ("\t1.-Generar Dataset\n\t2.-Clasificar Imagen\n\t3.-Salir\n"))#Menú de opciones que contiene la variable opcion de tipo int que servira para evaluar lo que hara el programa
os.system("cls")#función para limpiar la pantalla una vez que se halla seleccionado una opción
opcion_dos=0#variable de tipo entero que alamcenara un valor para evaluar la segunda parte del menú
while(opcion!=3):#ciclo while que evaluara la varialbe opcion que fuera ingresada por el usuario
    if(opcion<1 or opcion>3):#la variable opcion es validada con la finalidad de el usuario solo pueda saleccionar un rango de numero que debera estar entre el 1 y el 3
        print("Error")#si el numero seleccionado por el usuario no se encuentra dentro de rango 1:3 se mostrara en pantalla un mesaneje de error
    if (opcion==1):#se evalalua que el numero ingresado por el usuario sea igual a 1
        Dataset.dataset()#si el numero ingresado por el usuario es igual entonce invocamos al metodo Dataset y a la funcion dataset con la finalidad de generar un nuevo dataset
    if (opcion==2):#se evalua si el numero ingresado por el usuario es igual a 2 
        KNN_funciones.instancias()#se aplica la funcion de clasificacion del metodo KNN
    input("\n\nPulsa una tecla para continuar...")#impresion de pantalla para retrasar la limpieza de la pantalla
    os.system("cls")#limpieza de pantalla
    opcion_dos=int(input("Deseas Realizar algo mas?\n\t1.-SI\n\t2.-Salir\n"))#impresion de pantalla de nuevas acciones y guardamos en variable opcion_dos 
    os.system("cls")#limpieza de pantalla
    if (opcion_dos==1):#validamos que el valor que ingreso el usuario sea igual a uno 
        print ("Qué deseas realizar:")#impresion preguntando nuevamente que desea hacer
        opcion=int(input ("\t1.-Generar Dataset\n\t2.-Clasificar Imagen\n\t3.-Salir\n"))#mostramos opciones al usuario de las acciones que puede realizar y guardamos en la variable opcion
        os.system("cls")#limpiamos pantalla
    else:# que haremos en caso de que el usuario elija una opcion distinta al  1
        opcion=3#la variable opcion sera igual a 3 lo que finalizara el programa
if(opcion==3):#se evalua que el usuario haya escrito el numero 3 
    os.system("cls")#en caso de que se haya tecleado el numero 3 se limpiara la pantalla
    print("Adios")#se imprime mensaje de despedida


