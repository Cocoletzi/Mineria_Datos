# -*- coding: utf-8 -*-
"""
Created on Wed Feb 24 20:27:01 2016

@author: JuanCarlos
"""

import csv#importar librerias para archivos CSV
import math#importar libreria para funciones matematicas
import Caracteristicas#importar caracteristicas.py
import os#importar libreria del sistema operativo
"""
Nombre:      KNN_funciones
Descripción:Clasificamos una imagen utilizando knn para clasificacion de
            acuerdo a 14 caracteristicas previamente definidas y almacenadas
            en un archivo .csv
Parámetros de entrada: Ninguno
Parámetros de Salida: dataset, numero de vecinos
"""
def Clasificacion():#nombre de la funcion para clasificar la imagen
    limx,limy, imgplot, div_x,div_y=Caracteristicas.lectura()
    """llamamos a la funcion lectura que se encuetra en Caracteristicas.py
    y guardamos los valores de retorno en limx=limites en eje de las x
    limy=limite en el eje de las y, imgplot= contenido de la imagen, div_x= la
    mitad del tamaño de la imagen en el eje de las x, div_y=la mitad del tamaño de la imagen en el eje de las y"""
    relacion_1,relacion_2=Caracteristicas.primera_segunda_carac(limx, limy,imgplot)
    """llamamos a la funcion que contiene a las dos primeras caracterisiticas
    y las guardamos en las variables relacion_1=relacion del tamaño de la imagen, 
    relación_2= relacion del numero de pixeles blancos con negros """
    vertical_cambios,vertical_numero=Caracteristicas.tecera_cuarta_carac(limx,limy,imgplot,div_x,div_y)
    """llamamos a la funcion que contiene a las caracterisiticas tres y cuatro
    y las guardamos en las variables vertical_cambios= los cambios de color que existen 
    a mitad de la imagen con respecto a los pixeles que se encuentran en esa posicion, 
    vertical_numero= al numero de pixeles blancos que se encuentran a mitad de la imagen 
    con respecto a los pixeles en esa posicion"""
    horizontal_cambios,horizontal_numero=Caracteristicas.quinta_sexta_carac(limx,limy,imgplot,div_x,div_y)
    """llamamos a la funcion que contiene a las caracterisiticas cinco y seis
    y las guardamos en las variables horizontal_cambios=a los cambios de color que existen 
    a mitad de la imagen con respecto a los pixeles que se encuentran en esa posicion de las x , 
    horizontal_numero= al numero de pixeles blancos que se encuentran a mitad de la imagen 
    con respecto a los pixeles en esa posicion del eje x"""
    vertical_cambios_izquierda,vertical_cambios_numeros=Caracteristicas.septima_octava_carac(limx,limy,imgplot,div_x,div_y)
    """llamamos a la funcion que contiene a las caracterisiticas siete y ocho
    y las guardamos en las variables vertical_cambios_izquierda= los cambios de color que existen 
    del lado izquierdo de la primera cuarta parte de la imagen con respecto a los pixeles que se encuentran en esa posicion de las y, 
    vertical_cambios_numeros= al numero de pixeles blancos que se encuentran en la primera cuarta parte de la imagen 
    con respecto a los pixeles en esa posicion del eje y"""
    vertical_cambios_derecha,vertical_cambios_derecha_numeros=Caracteristicas.novena_decima_carac(limx,limy,imgplot,div_x,div_y)
    """llamamos a la funcion que contiene a las caracterisiticas nueve y diez
    y las guardamos en las variables vertical_cambios_derecha= los cambios de color que existen 
    del lado derecha de la ultima cuarta parte de la imagen con respecto a los pixeles que se encuentran en esa posicion de las y, 
    vertical_cambios_derecha_numeros= al numero de pixeles blancos que se encuentran en la ultima cuarta parte de la imagen 
    con respecto a los pixeles en esa posicion del eje y"""    
    horizontal_cambios_arriba, horizontal_numero_arriba=Caracteristicas.once_doce_carac(limx,limy,imgplot,div_x,div_y)
    """llamamos a la funcion que contiene a las caracterisiticas once y doce
    y las guardamos en las variables horizontal_cambios_arriba=a los cambios de color que existen 
    a  en la primera cuarta parte de arriba de la imagen con respecto a los pixeles que se encuentran en esa posicion de las x, 
    horizontal_numero_arriba= al numero de pixeles blancos que se encuentran a en la primera cuarta parte de la imagen 
    con respecto a los pixeles en esa posicion del eje x"""    
    horizontal_cambios_abajo, horizontal_numero_abajo=Caracteristicas.trece_catorce_caract(limx,limy,imgplot,div_x,div_y)    
    """llamamos a la funcion que contiene a las caracterisiticas trece y catorce
    y las guardamos en las variables horizontal_cambios_abajo=a los cambios de color que existen 
     en la ultima cuarta parte de abajo de la imagen con respecto a los pixeles que se encuentran en esa posicion de las x, 
    horizontal_numero_abajo= al numero de pixeles blancos que se encuentran a en la ultima cuarta parte de la imagen 
    con respecto a los pixeles en esa posicion del eje x"""       
    abrir= open('DataSet_Final.csv')#la variable abrir contendra todos los datos que se encuentran en el dataset
    leer_dataset=csv.reader(abrir)#la variable leer_dataset contriene los datos que se encuentran en abrir
    dataset=list(leer_dataset)#la variable dataset contendra el dataset en forma de lista
    print ("Por favor ingrese los datos solicitados")#impresion con instrucciones
    print("Numero de vecinos a considerar: ",end="")#impresion con intrucciones
    numero_vecinos=int(input())#la variabl numero_vecinos contendra el numero de vecinos que evaluaremos
    os.system("cls")#limpieza de pantalla
    contador=0#variable contador     
    for i in dataset:#for que recorre el dataset en todas sus posiciones
        dataset[contador][0]=float(dataset[contador][0])#convertirmos a flotante dataset en la posicion [contador][0]
        dataset[contador][1]=float(dataset[contador][1])#convertirmos a flotante dataset en la posicion [contador][1]
        dataset[contador][2]=int(dataset[contador][2])#convertirmos a entero dataset en la posicion [contador][2]
        dataset[contador][3]=int(dataset[contador][3])#convertirmos a entero dataset en la posicion [contador][3]
        dataset[contador][4]=int(dataset[contador][4])#convertirmos a entero dataset en la posicion [contador][4]
        dataset[contador][5]=int(dataset[contador][5])#convertirmos a entero dataset en la posicion [contador][5]
        dataset[contador][6]=int(dataset[contador][6])#convertirmos a entero dataset en la posicion [contador][6]
        dataset[contador][7]=int(dataset[contador][7])#convertirmos a entero dataset en la posicion [contador][7]
        dataset[contador][8]=int(dataset[contador][8])#convertirmos a entero dataset en la posicion [contador][8]
        dataset[contador][9]=int(dataset[contador][9])#convertirmos a entero dataset en la posicion [contador][9]
        dataset[contador][10]=int(dataset[contador][10])#convertirmos a entero dataset en la posicion [contador][10]
        dataset[contador][11]=int(dataset[contador][11])#convertirmos a entero dataset en la posicion [contador][11]
        dataset[contador][12]=int(dataset[contador][12])#convertirmos a entero dataset en la posicion [contador][12]
        dataset[contador][13]=int(dataset[contador][13])#convertirmos a entero dataset en la posicion [contador][13]
        dataset[contador][14]=int(dataset[contador][14])#convertirmos a entero dataset en la posicion [contador][14]
        dataset[contador][15]=int(dataset[contador][15])#convertirmos a entero dataset en la posicion [contador][15]         
        distancia_previa=(((dataset[contador][0]-relacion_1)**2)+((dataset[contador][1]-relacion_2)**2)
        +((dataset[contador][2]-vertical_cambios)**2)+((dataset[contador][3]-vertical_numero)**2)+
        ((dataset[contador][4]-horizontal_cambios)**2)+((dataset[contador][5]-horizontal_numero)**2)+
        ((dataset[contador][6]-vertical_cambios_izquierda)**2)+((dataset[contador][7]-vertical_cambios_numeros)**2)+
        ((dataset[contador][8]-vertical_cambios_derecha)**2)+((dataset[contador][9]-vertical_cambios_derecha_numeros)**2)+
        ((dataset[contador][10]-horizontal_cambios_arriba)**2)+((dataset[contador][11]-horizontal_numero_arriba)**2)+
        ((dataset[contador][12]-horizontal_cambios_abajo)**2)+((dataset[contador][13]-horizontal_numero_abajo)**2))
        """Aplicamos la formula para obtener la distancia Euclidiana, es decir una sumatoria de cada caracteristica del dataset
        menos cada caracteristica de la imagen a clasificar"""
        raiz=math.sqrt(distancia_previa)#la segunda parte de la formula es obtener la raiz cuadrada de la sumatoria
        dataset[contador].append(raiz)#agregamos una nueva fila a nuestra matriz que contendra la raiz cuadrada de cada instancia
        contador+=1#sumamos un numero al contador    
    dataset.sort(key=lambda dataset: dataset[14],reverse=True)#aplicamos la funcion sort para ordenar el dataset de acuerdo al numero total de instancias
    print ("\t\tDataset info:\nNúmero total de instancias:", dataset [0][14])#imprimimos el numoro de primera instancia despues del sort
    dataset.sort(key=lambda dataset: dataset[16])#aplicamos nuevo sort para ordenarlo de acuerdo a la distancia
    print("Instancia del K vecino mas cercano:", dataset[0][14])#imprimimos el numero  de la instancia con la distancia mas cercana a nuestra imagen
    print ("\nk vecinos mas cercanos:")#Impresion de pantalla
    for K_vecinos in range (0,numero_vecinos):#numero de kvecinos que deberan imprimirse
        print ("\tInstancia:", dataset[K_vecinos][14], "\tDistancia:",
               "%.5f" %dataset[K_vecinos][16], "\tClase", dataset[K_vecinos][15])#impresion de los k vecinos mas cercanos
    return dataset, numero_vecinos#valores que regresa la funcion clasificacion

"""
Nombre:      instancias
Descripción:Ordenamos e imprimimos las instancias, así como un resumen del dataset
Parámetros de entrada: Ninguno
Parámetros de Salida: Ninguno
Variables:
"""
def instancias():
    dataset,numero_vecinos=Clasificacion()#llamamos a la funcion clasificacion y los valores de retorno son almacenados en dos variables
    clase_0=0#variable de tipo int
    clase_1=0#variable de tipo int
    clase_2=0#variable de tipo int
    clase_3=0#variable de tipo int
    clase_4=0#variable de tipo int
    clase_5=0#variable de tipo int
    clase_6=0#variable de tipo int
    clase_7=0#variable de tipo int
    clase_8=0#variable de tipo int
    clase_9=0#variable de tipo int
    
    numero_filas=10#variable de tipo int
    numero_columnas=2#variable de tipo int
    clase_final = []#creamos un arreglo
    for filas in range(numero_filas):#limitaremos el numero de filas a 10
        clase_final.append([])#agregaremos mas filas a nuestas matriz
        for columnas in range(numero_columnas):#limitaremos el numero de columnas a 2
            clase_final[filas].append(None)#agregamos nuevas columnas a nuestra matriz         
    
    for caracteristica in range(0,numero_vecinos):#sumaremos el numero de vecinos que deseamos ver impresos
        if(dataset[caracteristica][15]==0):#condicion para determinar si en una posicion es igual a 0
            clase_0=clase_0+1#sumamos uno a nuestro contador         
        if(dataset[caracteristica][15]==1):#condicion para determinar si en una posicion es igual a 1
            clase_1=clase_1+1#sumamos uno a nuestro contador #sumamos uno a nuestro contador 
        if(dataset[caracteristica][15]==2):#condicion para determinar si en una posicion es igual a 2
            clase_2=clase_2+1#sumamos uno a nuestro contador 
        if(dataset[caracteristica][15]==3):#condicion para determinar si en una posicion es igual a 3
            clase_3=clase_3+1#sumamos uno a nuestro contador 
        if(dataset[caracteristica][15]==4):#condicion para determinar si en una posicion es igual a 4
            clase_4=clase_4+1#sumamos uno a nuestro contador 
        if(dataset[caracteristica][15]==5):#condicion para determinar si en una posicion es igual a 5
            clase_5=clase_5+1#sumamos uno a nuestro contador 
        if(dataset[caracteristica][15]==6):#condicion para determinar si en una posicion es igual a 6
            clase_6=clase_6+1#sumamos uno a nuestro contador 
        if(dataset[caracteristica][15]==7):#condicion para determinar si en una posicion es igual a 7
            clase_7=clase_7+1#sumamos uno a nuestro contador 
        if(dataset[caracteristica][15]==8):#condicion para determinar si en una posicion es igual a 8
            clase_8=clase_8+1#sumamos uno a nuestro contador 
        if(dataset[caracteristica][15]==9):#condicion para determinar si en una posicion es igual a 9
            clase_9=clase_9+1#sumamos uno a nuestro contador 
            
    clase_final[0]=clase_0,0#llenamos nuestra matriz clse_final con los valores de la clase y el numero 0
    clase_final[1]=clase_1,1#llenamos nuestra matriz clse_final con los valores de la clase y el numero 1
    clase_final[2]=clase_2,2#llenamos nuestra matriz clse_final con los valores de la clase y el numero 2
    clase_final[3]=clase_3,3#llenamos nuestra matriz clse_final con los valores de la clase y el numero 3
    clase_final[4]=clase_4,4#llenamos nuestra matriz clse_final con los valores de la clase y el numero 4
    clase_final[5]=clase_5,5#llenamos nuestra matriz clse_final con los valores de la clase y el numero 5
    clase_final[6]=clase_6,6#llenamos nuestra matriz clse_final con los valores de la clase y el numero 7
    clase_final[7]=clase_7,7#llenamos nuestra matriz clse_final con los valores de la clase y el numero 8
    clase_final[8]=clase_8,8#llenamos nuestra matriz clse_final con los valores de la clase y el numero 9
    clase_final[9]=clase_9,9#llenamos nuestra matriz clse_final con los valores de la clase y el numero 10
    
    clase_final.sort(key=None, reverse=True)#aplicamos sort a nuestra matriz clase_final dejando al principio el numero mayor
    print ("\nNúmero de Instancias por clase:")#impresion de pantalla
    for conteo_instancias in range(0,10):#contaremos el numero de instancias
            print ("\t",clase_final[conteo_instancias][0],
            "\tInstancias de la clase:",clase_final[conteo_instancias][1]) 
    print ("\nLa imagen es el numero:", clase_final[0][1]) #impresion de pantalla del numero de instancias
