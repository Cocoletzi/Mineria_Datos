# -*- coding: utf-8 -*-
"""
Created on Mon Feb 22 10:06:02 2016

@author: JuanCarlos
"""
import matplotlib.image as mpimg#importar una funcion de la libreria matplotlib y guardamos como mpimg
import csv#importamos libreria para archivos csv
import os#importamos librerias de sistema operativo
import Caracteristicas#importamos caracteristicas.py
"""
Nombre:      dataset()
Descripción:Generamos un dataset en un archivo.csv que contiene 14 caracteristicas, una clase
Parámetros de entrada: Ninguno
Parámetros de Salida: dataset.csv
"""
def dataset():
    root='Numeros'#Es el nombre de la carpeta en donde se encuentra nuestos numeros
    archivo= open('DataSet_Final.csv', 'w', newline='')#creamos un nuevo archivo .csv con el nombre de DataSet_final.csv
    salida = csv.writer(archivo)#variable que nos permite escribir en un archivo csv 
    porcentaje=''#variable de tipo str
    clase=0#varialbe de tipo int
    posiciones_dataset=0#variable de tipo int
    for dirName, subdirList, fileList in os.walk(root):#podremos recorrer todas las carpetas y subcarpetas de una ruta
        print("Estamos trabajando en el dataset\n",porcentaje)#impresion de pantalla
        porcentaje=porcentaje+'.#'#escribimos una cadena con .#        
        for fname in fileList:#leemos todos los archivos que se encuentran en las subcarpetas
            posiciones_dataset=posiciones_dataset+1#aumentamos en uno el valor de la posicion
            nameima=dirName+'/'+fname#entramos a una nueva subcarpeta
            imgplot=mpimg.imread(nameima)#leemos una imagen
            imagen=imgplot.shape#obtenemos las medidas de las imagenes
            limx= imagen[1]#guardamos enuna variable de tipo entero el la poscion de imagen
            limy= imagen[0]#guardamos enuna variable de tipo entero el la poscion de imagen
            div_x=int(limx/2)#obtenemos la mitad del tamaño de lo ancho de la imagen 
            div_y=int(limy/2)#obtenemos la mitad del tamaño de lo alto de la imagen
            relacion_1,relacion_2=Caracteristicas.primera_segunda_carac(limx, limy,imgplot)#obtenrmos las primeras dos caracteristicas de la imagen
            recta_cambios,recta_numero=Caracteristicas.tecera_cuarta_carac(limx,limy,imgplot,div_x,div_y)#caracteristicas tres y cuatro
            perpendicular_cambios,perpendicular_numero=Caracteristicas.quinta_sexta_carac(limx,limy,imgplot,div_x,div_y)##caracteristicas cinco y seis
            recta_cambios_izquierda,recta_cambios_numeros=Caracteristicas.septima_octava_carac(limx,limy,imgplot,div_x,div_y)#caracteristicas siete y ocho
            recta_cambios_derecha,recta_cambios_derecha_numeros=Caracteristicas.novena_decima_carac(limx,limy,imgplot,div_x,div_y)#caracteristicas nueve y diez
            perpendicular_cambios_arriba, perpendicular_numero_arriba=Caracteristicas.once_doce_carac(limx,limy,imgplot,div_x,div_y)#caracteristicas once y doce
            perpendicular_cambios_abajo, perpendicular_numero_abajo=Caracteristicas.trece_catorce_caract(limx,limy,imgplot,div_x,div_y)#caracteristicas trece y catorce                 
            salida.writerow([relacion_1,relacion_2, recta_cambios,recta_numero,perpendicular_cambios, 
                             perpendicular_numero, recta_cambios_izquierda,recta_cambios_numeros, recta_cambios_derecha,
                             recta_cambios_derecha_numeros, perpendicular_cambios_arriba, perpendicular_numero_arriba,
                             perpendicular_cambios_abajo, perpendicular_numero_abajo,posiciones_dataset,clase-1])#escribimos todas las caracteristicas en un archivo.csv
        clase=clase+1#aumentamos en uno al contador 
        os.system("cls")#limpiamos pantalla
    print ("Dataset Terminado")#impresion de pantalla    
    archivo.close()#dejamos de escribir en el dataset