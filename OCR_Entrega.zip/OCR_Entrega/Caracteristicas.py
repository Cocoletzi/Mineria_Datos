# -*- coding: utf-8 -*-
"""
Created on Thu Feb 25 13:53:29 2016

@author: verticalCarlos
"""
import matplotlib.image as mpimg#importar una funcion de la libreria matplotlib y guardamos como mpimg
import os#importamos librerias de sistema operativo
"""
Nombre:      datos_imagen
Descripción: Leemos imagenes y las guardamos en un arreglo
Parámetros de entrada: Ninguno
Parámetros de Salida: img
"""
def datos_imagen():
    print("Nombre de la imagen: ")#impresion de pantalla
    nombre_imagen=(input())#variable de tipo int
    os.system("cls")#limpiar pantalla
    img=mpimg.imread(nombre_imagen)#leemos la imagen y guardamos en una variable
    #img_dos=img
    #img_dos=plt.imshow(img_dos)
    return img#regresamos un arreglo con los datos de la imagen
"""
Nombre:      lectura
Descripción: leemos los valores de la imagen tales como tamaño de lo alto y ancho
Parámetros de entrada: Ninguno
Parámetros de retorno: limx,limy, imgplot, div_x,div_y
"""    
def lectura():
    img=datos_imagen()#llamamos a la funcion datos imagen y la almacenamos en la variable img
    imgplot=img#copiamos la variable img en imgplot
    imagen=imgplot.shape#obtenemos las medidas de la imagen en alto y ancho
    limx= imagen[1]#obtenemos las medidas de lo ancho
    limy= imagen[0]#obtenemos las medidas de lo alto
    div_x=int(limx/2)#dividimos el ancho entre dos y lo guardamos en div_x
    div_y=int(limy/2)#dividimos el alto entre dos y lo guardamos en div_y
    return limx,limy, imgplot, div_x,div_y#regresamos 4 datos y un arreglo
"""
Nombre:      primera_segunda_carac
Descripción: obtenemos las dos primeras caracteristicas de la imagen, la primera consiste en la relacion que existe
            entre el alto y el acho de la imagen, la segunda es respecto al numero de pixeles blancos de la totalidad de pixeles
Parámetros de entrada: tamaño de alto y ancho, iamgen
Parámetros de retorno: relacion_1, relacion_2
"""    
def primera_segunda_carac(limx, limy,imgplot):
    relacion_1=limy/limx#dividimos el alto entre el ancho para saber la relacion de la imagen
    fila=0#variable de tipo entero
    columna=0#variable de tipo entero
    relacion_2=0#variable de tipo entero
    aux=0#variable de tipo entero
    for fila in range (0, limy):#recorreremos la imagen hasta el limite de lo alto
        for columna in range (0,limx):#recorremos la imagen hasta el limite de lo ancho
            if (imgplot[fila,columna]==1):#revisamos el numero que contiene la matriz en cada posicion
                aux=aux+1#si es un 1 aumentamos en 1 el contador
    relacion_2=(limx*limy)/aux#multiplicamos el tamoño de la imagen para saber la totalidad de pixeles y luego la dividimos entre el total de auxiliares
    return relacion_1, relacion_2#regresamos las primeras dos caracteristicas
"""
Nombre:      tercera_cuarta_carac
Descripción: obtenemos caracteristicas tres(el numero de cambios de color en la parte media de la imagen) y cuatro (el numero
            total de pixeles blancos en la parte media de la imagen)
Parámetros de entrada: tamaño de alto y ancho, iamgen y la mitad de la imagen en lo alto y lo ancho
Parámetros de retorno: vertical_cambios,vertical_numero
"""    
def tecera_cuarta_carac(limx,limy,imgplot,div_x,div_y):
    fila=0#variable de tipo entero 
    vertical_cambios=0#variable de tipo entero 
    vertical_numero=0#variable de tipo entero 
    aux=imgplot[fila,div_x]#variable de tipo entero 
    for fila in range (0, limy):#for que recorre la fila hasta la ultima posicion de la imagen
        if (imgplot[fila, div_x]!=aux):#condicion para detectar los cambios de color
            vertical_cambios=vertical_cambios+1#aumentamos en uno el contador si se cumple la condicion
            aux=imgplot[fila,div_x]#el auxiliar toma el valor del pixel anterior
        if (imgplot[fila, div_x]==1):#condicion para detectar la totalida de blancos a la mitad de la imagen
            vertical_numero=vertical_numero+1#aumentamos en uno el contador
    return vertical_cambios,vertical_numero#regresamos las dos caracteristicas

"""
Nombre:      quinta_sexta_carac
Descripción: obtenemos caracteristicas cinco (el numero de cambios de color de la mitad de la imagen trazando una linea horizontal) 
            y seis (el numero de pixeles blancos de la mitad de la imagen trazando una linea horizontal) de la imagen
Parámetros de entrada: tamaño de alto y ancho, iamgen y la mitad de la imagen en lo alto y lo ancho
Parámetros de retorno: horizontal_cambios, horizontal_numero
"""    
def quinta_sexta_carac(limx,limy,imgplot,div_x,div_y):
    columna=0#variable de tipo entero
    horizontal_cambios=0#variable de tipo entero
    horizontal_numero=0#variable de tipo entero
    aux=imgplot[div_y,columna]#variable de tipo entero
    for columna in range (0, limx):#for que recorre la columna hasta la ultima posicion de la imagen
        if (imgplot[div_y, columna]!=aux):#condicion para detectar los cambios de color
            horizontal_cambios=horizontal_cambios+1#aumentamos en uno el contador si se cumple la condicion
            aux=imgplot[div_y,columna] #el auxiliar toma el valor del pixel anterior               
        if (imgplot[div_y, columna]==1):#condicion para detectar la totalida de blancos en la mitad de la imagen en linea horizontal
            horizontal_numero=horizontal_numero+1#aumentamos en uno el contador
    return horizontal_cambios, horizontal_numero#regresamos las dos caracteristicas
"""
Nombre:     septima_octava_carac
Descripción: obtenemos caracteristicas siete(el numero de cambios de color de la primera cuarta parte de la imagen trazando una linea vertical) 
            ocho (el numero de pixeles blancos de la primera cuarta parte de la imagen trazando una linea vertical) de la imagen
Parámetros de entrada: tamaño de alto y ancho, iamgen y la mitad de la imagen en lo alto y lo ancho
Parámetros de retorno: vertical_cambios_izquierda,vertical_cambios_numeros_izquierda
"""        
def septima_octava_carac(limx,limy,imgplot,div_x,div_y):
    fila=0#variable de tipo entero
    vertical_cambios_izquierda=0#variable de tipo entero
    vertical_cambios_numeros_izquierda=0#variable de tipo entero
    division=int(limx/4)#variable de tipo entero en la que dividimos el ancho de la imagen en 4 
    aux=imgplot[fila,division]#variable de tipo entero
    for fila in range (0, limy):#for que recorre la fila hasta la ultima posicion de la imagen
        if (imgplot[fila, division]!=aux):#condicion para detectar los cambios de color en la parte izquierda de la imagen
            vertical_cambios_izquierda=vertical_cambios_izquierda+1#aumentamos en uno el contador si se cumple la condicion
            aux=imgplot[fila,division]#el auxiliar toma el valor del pixel anterior
        if (imgplot[fila, division]==1):#condicion para detectar la totalida de blancos en cuartpa parte izquierda de la imagen en linea horizontal
            vertical_cambios_numeros_izquierda=vertical_cambios_numeros_izquierda+1#aumentamos en uno el contador       
    return vertical_cambios_izquierda,vertical_cambios_numeros_izquierda#regresamos las dos caracteristicas
"""
Nombre:     novena_decima_carac
Descripción: obtenemos caracteristicas nueve(el numero de cambios de color de la ultima cuarta parte de la imagen trazando una linea vertical) 
            decima (el numero de pixeles blancos de la ultima cuarta parte de la imagen trazando una linea vertical) de la imagen
Parámetros de entrada: tamaño de alto y ancho, iamgen y la mitad de la imagen en lo alto y lo ancho
Parámetros de retorno: vertical_cambios_derecha,vertical_cambios_numeros_derecha
"""       
def novena_decima_carac(limx,limy,imgplot,div_x,div_y):
    fila=0#variable de tipo entero
    vertical_cambios_derecha=0#variable de tipo entero
    vertical_cambios_numeros_derecha=0#variable de tipo entero
    division=int (limx/4)#variable de tipo entero en la que dividimos el alto de la imagen en 4 
    division=limx-division#al tamaño del ancho de la imagen le restaremos el resultado de la division
    aux=imgplot[fila,division]#variable de tipo entero
    for fila in range (0, limy):#for que recorre la fila hasta la ultima posicion de la imagen
        if (imgplot[fila, division]!=aux):#condicion para detectar los cambios de color en la parte derecha de la imagen
            vertical_cambios_derecha=vertical_cambios_derecha+1#aumentamos en uno el contador si se cumple la condicion
            aux=imgplot[fila,division]#el auxiliar toma el valor del pixel anterior
        if (imgplot[fila, division]==1):#condicion para detectar la totalida de blancos en cuartpa parte derecha de la imagen en linea horizontal
            vertical_cambios_numeros_derecha=vertical_cambios_numeros_derecha+1  #aumentamos en uno el contador      
    return vertical_cambios_derecha,vertical_cambios_numeros_derecha#regresamos las dos caracteristicas
"""
Nombre:     once_doce_carac
Descripción: obtenemos caracteristicas once(el numero de cambios de color de la primera cuarta parte de la imagen trazando una linea horizontal, es decir parte de arriba) 
            doce (el numero de pixeles blancos de la primera cuarta parte de la imagen trazando una linea horizontal, parte arriba) de la imagen
Parámetros de entrada: tamaño de alto y ancho, iamgen y la mitad de la imagen en lo alto y lo ancho
Parámetros de retorno:  horizontal_cambios_arriba, horizontal_numero_arriba
"""     
def once_doce_carac(limx,limy,imgplot,div_x,div_y):
    columna=0#variable de tipo entero
    horizontal_cambios_arriba=0#variable de tipo entero
    horizontal_numero_arriba=0#variable de tipo entero
    division=int (limy/4)#variable de tipo entero en la que dividimos el ancho de la imagen en 4 
    aux=imgplot[division,columna]#variable de tipo entero
    for columna in range (0, limx):#for que recorre la columna hasta la ultima posicion de la imagen
        if (imgplot[division, columna]!=aux):#condicion para detectar los cambios de color en la parte de arriba de la imagen
            horizontal_cambios_arriba=horizontal_cambios_arriba+1#aumentamos en uno el contador si se cumple la condicion
            aux=imgplot[division,columna]#el auxiliar toma el valor del pixel anterior                
        if (imgplot[division, columna]==1):#condicion para detectar la totalida de blancos en cuartpa parte de arriba de la imagen en linea horizontal
            horizontal_numero_arriba=horizontal_numero_arriba+1#aumentamos en uno el contador    
    return horizontal_cambios_arriba, horizontal_numero_arriba#regresamos las dos caracteristicas
"""
Nombre:     trece_catorce_carac
Descripción: obtenemos caracteristicas trece(el numero de cambios de color de la ultima cuarta parte de la imagen trazando una linea horizontal, parte baja de la imagen) 
            catorce (el numero de pixeles blancos de la ultima cuarta parte de la imagen trazando una linea horizontal) de la imagen
Parámetros de entrada: tamaño de alto y ancho, iamgen y la mitad de la imagen en lo alto y lo ancho
Parámetros de retorno:  horizontal_cambios_abajo,horizontal_numero_abajo
"""    
def trece_catorce_caract(limx,limy,imgplot,div_x,div_y):
    columna=0#variable de tipo entero
    horizontal_cambios_abajo=0#variable de tipo entero
    horizontal_numero_abajo=0#variable de tipo entero
    division=int (limy/4)#variable de tipo entero en la que dividimos el ancho de la imagen en 4 
    division=limy-division#variable de tipo entero en la que restamos la divison al alto de la imagen 
    aux=imgplot[division,columna]#variable de tipo entero
    for columna in range (0, limx):#for que recorre la columna hasta la ultima posicion de la imagen
        if (imgplot[division, columna]!=aux):#condicion para detectar los cambios de color en la parte de abajo de la imagen
            horizontal_cambios_abajo=horizontal_cambios_abajo+1#aumentamos en uno el contador si se cumple la condicion
            aux=imgplot[division,columna]#el auxiliar toma el valor del pixel anterior                    
        if (imgplot[division, columna]==1):#condicion para detectar la totalida de blancos en cuartpa parte de abajo de la imagen en linea horizontal
            horizontal_numero_abajo=horizontal_numero_abajo+1#aumentamos en uno el contador    
    return horizontal_cambios_abajo,horizontal_numero_abajo#regresamos las dos caracteristicas