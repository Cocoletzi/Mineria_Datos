# -*- coding: utf-8 -*-
"""
Created on Sun Feb 28 14:11:10 2016

@author: JuanCarlos
"""

import KNN_funciones #importamos KNN_funciones para el manejo de las función KNN que programamos con anterioridad
import Dataset #importamos Dataset para la creacion del nuestro Dataset
import os #importamos os para usar comandos propios del Sistema Operativo
print ("Qué deseas realizar:")#impresion del menú para realizar la primera acción
opcion=int(input ("\t1.-Generar Dataset\n\t2.-Clasificar Imagen\n\t3.-Salir\n"))#Menú de opciones que contiene la variable opcion de tipo int que servira para evaluar lo que hara el programa
os.system("cls")#función para limpiar la pantalla una vez que se halla seleccionado una opción
opcion_dos=0#variable de tipo entero que alamcenara un valor para evaluar la segunda parte del menú
if(opcion<1 or opcion>3):#la variable opcion es validada con la finalidad de el usuario solo pueda saleccionar un rango de numero que debera estar entre el 1 y el 3
    print("Error")#si el numero seleccionado por el usuario no se encuentra dentro de rango 1:3 se mostrara en pantalla un mesaneje de error
if (opcion==1):#se evalalua que el numero ingresado por el usuario sea igual a 1
    Dataset.dataset()#si el numero ingresado por el usuario es igual entonce invocamos al metodo Dataset y a la funcion dataset con la finalidad de generar un nuevo dataset
if (opcion==2):#se evalua si el numero ingresado por el usuario es igual a 2 
    KNN_funciones.Clasificacion()#se aplica la funcion de clasificacion del metodo KNN
if(opcion==3):#se evalua que el usuario haya escrito el numero 3 
    os.system("cls")#en caso de que se haya tecleado el numero 3 se limpiara la pantalla
    print("Adios")#se imprime mensaje de despedida